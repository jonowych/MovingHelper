#MovingHelper

A sample project for a [RayWenderlich.com](http://www.raywenderlich.com) tutorial on setting up continuous integration with GitHub and Travis CI. 